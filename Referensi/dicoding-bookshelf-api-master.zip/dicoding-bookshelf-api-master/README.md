## About
Repository ini digunakan untuk memberikan referensi pada teman-teman yang sedang belajar didalam kelas
[**Belajar Membuat Aplikasi Back-End untuk Pemula**](https://www.dicoding.com/academies/261/) dengan
menggunakan Node.js sebagai teknologi Back-End dan [Hapi.js](https://github.com/hapijs/hapi) sebagi implementasinya.

## License
Anda harus patuh kepada [Terms Of Service](https://www.dicoding.com/termsofuse) Dicoding Indonesia, apabila 
anda mengklaim repository ini sebagai hasil karya anda, maka admin Dicoding akan menangguhkan akun anda.
Dan ada reaksi lain yakni **Progress belajar anda akan di reset, dan anda tidak akan diberikan kelas beasiswa**

## Copyright
Aplikasi ini dibuat oleh [@khafidprayoga](https://github.com/khafidprayoga), namun semua kode yang ditulis,
tidak 100% hasil pemikiran saya, melainkan hasil observasi dari Forum Diskusi, dan beberapa sumber lain
seperti StackOverflow.  
Copyright &copy; 2021
