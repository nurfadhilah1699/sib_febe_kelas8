# Bookshelf API

Proyek ini adalah submission dari Dicoding untuk kelas Belajar Membuat Aplikasi Back-End untuk Pemula.
Submission berupa aplikasi Back-End Bookshelf API yang memiliki fungsi Create, Read, Update, dan Delete (CRUD).

Please give star if this helps you
